package android.makaylajohnsonc196new.Database;

import android.content.Context;
import android.makaylajohnsonc196new.ClassEntities.AssessmentEntity;
import android.makaylajohnsonc196new.DAO.AssessmentDAO;
import android.makaylajohnsonc196new.DAO.CourseDAO;
import android.makaylajohnsonc196new.DAO.TermDAO;
import android.makaylajohnsonc196new.ClassEntities.CourseEntity;
import android.makaylajohnsonc196new.ClassEntities.TermEntity;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {TermEntity.class, CourseEntity.class,AssessmentEntity.class}, version = 8)
public abstract class SchedulingManagementDatabase extends RoomDatabase {
    public abstract TermDAO termDAO();
    public abstract CourseDAO courseDAO();
    public abstract AssessmentDAO assessmentDAO();
    private static final int NUMBER_OF_THREADS = 4;

    /**
     * The Database write executor.
     */

    static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    private static volatile SchedulingManagementDatabase INSTANCE;

    static SchedulingManagementDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (SchedulingManagementDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(), SchedulingManagementDatabase.class, "scheduling_management_database.db")
                            .fallbackToDestructiveMigration()
                            .addCallback(roomDatabaseCallback)
                            .build();
                }
            }
        }
        return INSTANCE;
    }
    private static RoomDatabase.Callback roomDatabaseCallback = new RoomDatabase.Callback() {

        @Override
        public void onOpen(@NonNull SupportSQLiteDatabase db) {
            super.onOpen(db);
            // If you want to keep the data through app restarts,
            // comment out the following line.
            databaseWriteExecutor.execute(() -> {
                // Populate the database in the background.
                /**
                 * Populate the database in the background.
                 * If you want to start with more words, just add them.
                 */


                CourseDAO courseDAO = INSTANCE.courseDAO();
                TermDAO termDAO = INSTANCE.termDAO();
                AssessmentDAO assessmentDAO = INSTANCE.assessmentDAO();

                // Start the app with a clean database every time.
                // Not needed if you only populate on creation.
               // termDAO.deleteAllTerms();
                //courseDAO.deleteAllCourses();

                CourseEntity course = new CourseEntity(1,1 ,"Mobile Application", "May", "June","active","Miss Smartie","22222222",
                        "smartie@gmail.com","Long Class");
                courseDAO.insert(course);

                CourseEntity course2 = new CourseEntity(2,1 ,"Java 2", "Jan", "Feb","complete","Miss Smartie","22222222",
                        "smartie@gmail.com","Long Class");
                courseDAO.insert(course2);

                CourseEntity course3 = new CourseEntity(3,1, "Java 1", "Dec", "Jan","complete","Miss Smartie","22222222",
                        "smartie@gmail.com","Long Class");
                courseDAO.insert(course3);

                CourseEntity course4 = new CourseEntity(4,2, "Capstone", "Aug", "Sep","scheduled","Miss Smartie","22222222",
                        "smartie@gmail.com","Long Class");
                courseDAO.insert(course4);

                CourseEntity course5 = new CourseEntity(5,2, "Software Engineering", "May", "June","active","Miss Smartie","22222222",
                        "smartie@gmail.com","Long Class");
                courseDAO.insert(course5);

                CourseEntity course6 = new CourseEntity(6,2, "Java 3", "Jan", "Feb","complete","Miss Smartie","22222222",
                        "smartie@gmail.com","Long Class");
                courseDAO.insert(course6);

                CourseEntity course7 = new CourseEntity(7,3, "Java 4", "Dec", "Jan","complete","Miss Smartie","22222222",
                        "smartie@gmail.com","Long Class");
                courseDAO.insert(course7);

                CourseEntity course8 = new CourseEntity(8,3, "C#", "Aug", "Sep","scheduled","Miss Smartie","22222222",
                        "smartie@gmail.com","Long Class");
                courseDAO.insert(course8);


                TermEntity term = new TermEntity(1, "Winter Term", "2020","2021");
                termDAO.insert(term);


                TermEntity term2 = new TermEntity(2, "Spring Term","2020","2021");
                termDAO.insert(term2);

                TermEntity term3 = new TermEntity(3, "Summer Term","2020","2021");
                termDAO.insert(term3);

                AssessmentEntity assessment = new AssessmentEntity(1,"OA","August",1);
                assessmentDAO.insert(assessment);
                AssessmentEntity assessment1 = new AssessmentEntity(2,"PA","August",2);
                assessmentDAO.insert(assessment1);
                AssessmentEntity assessment2 = new AssessmentEntity(3,"OA","August",3);
                assessmentDAO.insert(assessment2);
                AssessmentEntity assessment3 = new AssessmentEntity(4,"Cert","August",4);
                assessmentDAO.insert(assessment3);
                AssessmentEntity assessment4 = new AssessmentEntity(5,"Cert","August",5);
                assessmentDAO.insert(assessment4);
                AssessmentEntity assessment5 = new AssessmentEntity(6,"OA","August",6);
                assessmentDAO.insert(assessment5);
                AssessmentEntity assessment6 = new AssessmentEntity(7,"PA","August",7);
                assessmentDAO.insert(assessment6);
                AssessmentEntity assessment7 = new AssessmentEntity(8,"OA","August",8);
                assessmentDAO.insert(assessment7);
                AssessmentEntity assessment8 = new AssessmentEntity(9,"Cert","August",9);
                assessmentDAO.insert(assessment8);


            });
        }
    };
}
