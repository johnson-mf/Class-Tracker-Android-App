package android.makaylajohnsonc196new.UI;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.makaylajohnsonc196new.ClassEntities.AssessmentEntity;
import android.makaylajohnsonc196new.ClassEntities.CourseEntity;
import android.makaylajohnsonc196new.ClassEntities.TermEntity;
import android.makaylajohnsonc196new.Database.SchedulingManagementRepository;
import android.makaylajohnsonc196new.R;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

//course -> assessment
//term-> course
public class AddAssessmentActivity extends AppCompatActivity {
    private SchedulingManagementRepository schedulingManagementRepository;
    static int id2;
    List<AssessmentEntity> filteredAssessments = new ArrayList<>();
    AssessmentEntity currentAssessment;

    int id;
    Integer courseID;
    String title;
    String endDate;

    EditText editTitle;
    EditText editEndDate;

    //alert and datepicker variables
    Calendar calendarStart=Calendar.getInstance();
    Calendar calendarEnd=Calendar.getInstance();
    DatePickerDialog.OnDateSetListener  myEndDate;
    Long endDateLong;
    public static int numAlert;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_assessment);

        //what is happening here?
        id = getIntent().getIntExtra("assessmentID", -1);
        title = getIntent().getStringExtra("assessmentTitle");
        endDate = getIntent().getStringExtra("assessmentEndDate");
        courseID = getIntent().getIntExtra("realCourseID",-1);

        id2 = courseID;
        System.out.println(" CourseID : " + courseID);
        editTitle = findViewById(R.id.assessment_edit_title);
        editEndDate = findViewById(R.id.assessment_edit_end);

        if(id!=-1){
            editTitle.setText(title);
            editEndDate.setText(endDate);
        }

        schedulingManagementRepository = new SchedulingManagementRepository(getApplication());
        myEndDate = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                calendarEnd.set(Calendar.YEAR, year);
                calendarEnd.set(Calendar.MONTH, monthOfYear);
                calendarEnd.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                String myFormat = "MM/dd/yy"; //In which you need put here
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                updateEndDateLabel();
            }

        };
        editEndDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(AddAssessmentActivity.this, myEndDate, calendarEnd
                        .get(Calendar.YEAR), calendarEnd.get(Calendar.MONTH),
                        calendarEnd.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        List<AssessmentEntity> allAssessments = schedulingManagementRepository.getAllAssessments();

        //search the list of our terms to pull out which term we want to edit.

        for (AssessmentEntity a : allAssessments) {
            if (a.getId() == id)
                currentAssessment = a;
        }

        // what is happening here?
        if(currentAssessment!=null) {
            title = currentAssessment.getTitle();
            endDate = currentAssessment.getEndDate();
            courseID = currentAssessment.getCourseID();
            System.out.println(" CourseID : " + courseID);

        }
        schedulingManagementRepository = new SchedulingManagementRepository(getApplication());

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.delete_assessment, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //logic for deleting a course
        int id = item.getItemId();

        if (id == R.id.notifyEndDate) {
            Intent intent=new Intent(AddAssessmentActivity.this,MyReceiver.class);
            intent.putExtra("key","Notification for Assessment: " + currentAssessment.getTitle() + " with an End Date of: " + currentAssessment.getEndDate());
            PendingIntent sender= PendingIntent.getBroadcast(AddAssessmentActivity.this,++numAlert,intent,0);
            AlarmManager alarmManager=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
            endDateLong=calendarEnd.getTimeInMillis();
            alarmManager.set(AlarmManager.RTC_WAKEUP, endDateLong, sender);
            return true;
        }
        if (id == R.id.deleteAssesssment) {

                schedulingManagementRepository.delete(currentAssessment);
        }

        Intent intent=new Intent(AddAssessmentActivity.this,CourseActivity.class);
        startActivity(intent);
        return super.onOptionsItemSelected(item);

    }
    private void updateEndDateLabel() {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        editEndDate.setText(sdf.format(calendarEnd.getTime()));
    }
    public void addAssessmentFromScreen(View view) {
        AssessmentEntity a;
        // the course ID is sent from the course detail screen!
        if(id!=-1) {
            a = new AssessmentEntity(id, editTitle.getText().toString(), editEndDate.getText().toString(), courseID);


        }else {
            List<AssessmentEntity> allAssessments = schedulingManagementRepository.getAllAssessments();
            id = allAssessments.get(allAssessments.size() - 1).getId();

            a = new AssessmentEntity( ++id, editTitle.getText().toString(), editEndDate.getText().toString(), courseID);

       }

        schedulingManagementRepository.insert(a);

        Intent intent=new Intent(AddAssessmentActivity.this,CourseActivity.class);
        startActivity(intent);
    }
}