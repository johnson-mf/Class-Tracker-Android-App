package android.makaylajohnsonc196new.UI;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.makaylajohnsonc196new.ClassEntities.TermEntity;
import android.makaylajohnsonc196new.Database.SchedulingManagementRepository;
import android.makaylajohnsonc196new.R;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;

import java.util.List;

public class TermActivity extends AppCompatActivity {
private SchedulingManagementRepository schedulingManagementRepository;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        CourseDetail.id2=-1;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_term);
        schedulingManagementRepository = new SchedulingManagementRepository(getApplication());
        //schedulingManagementRepository.getAllTerms();
        RecyclerView recyclerView = findViewById(R.id.term_recyclerview);
        List<TermEntity> allTerms = schedulingManagementRepository.getAllTerms();
        final TermAdapter adapter = new TermAdapter(this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter.setWords(allTerms);
    }

    public void addTerm(View view) {
        Intent intent= new Intent(TermActivity.this, AddTermActivity.class);
        startActivity(intent);
    }
}