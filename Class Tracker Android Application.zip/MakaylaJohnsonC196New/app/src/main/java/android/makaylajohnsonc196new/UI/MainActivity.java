package android.makaylajohnsonc196new.UI;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.makaylajohnsonc196new.R;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
//to go to the next screen, you make an intent, and state the current activity, then the activity you want to go to. then call the startActivity method with the intent as the parameter
    public void onTermActivity(View view) {
        Intent intent = new Intent(MainActivity.this, TermActivity.class);
        startActivity(intent);
    }
}