package android.makaylajohnsonc196new.UI;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.makaylajohnsonc196new.ClassEntities.AssessmentEntity;
import android.makaylajohnsonc196new.ClassEntities.CourseEntity;
import android.makaylajohnsonc196new.Database.SchedulingManagementRepository;
import android.makaylajohnsonc196new.R;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class AddCourseActivity extends AppCompatActivity {
    private SchedulingManagementRepository schedulingManagementRepository;

    static int id2;
    int id;
    int termID;
    String title;
    String startDate;
    String endDate;
    String status;
    String instructorName;
    String instructorPhone;
    String instructorEmail;
    String notes;
    EditText editTitle;
    EditText editStartDate;
    EditText editEndDate;
    EditText editStatus;
    EditText editInstructorName;
    EditText editInstructorPhone;
    EditText editInstructorEmail;
    EditText editNotes;
    List<AssessmentEntity> filteredAssessments = new ArrayList<>();
    CourseEntity currentCourse;
    Calendar calendarStart=Calendar.getInstance();
    Calendar calendarEnd=Calendar.getInstance();
    DatePickerDialog.OnDateSetListener  myStartDate;
    DatePickerDialog.OnDateSetListener  myEndDate;
    Long date;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_course);
        // when we go to the course detail screen, the id will be set to id2.
        //what is happening here?
        id = getIntent().getIntExtra("courseID", -1);
        title = getIntent().getStringExtra("courseTitle");
        startDate = getIntent().getStringExtra("courseStartDate");
        endDate = getIntent().getStringExtra("courseEndDate");
        status = getIntent().getStringExtra("courseStatus");
        instructorName = getIntent().getStringExtra("instructorName");
        instructorPhone = getIntent().getStringExtra("instructorPhone");
        instructorEmail = getIntent().getStringExtra("instructorEmail");
        notes = getIntent().getStringExtra("notes");
        termID = getIntent().getIntExtra("termID", -1);
        id2 = termID;
        String termIDString = String.valueOf(termID);
        editTitle = findViewById(R.id.courseTitle);
        editStartDate = findViewById(R.id.courseStartDate);
        editEndDate = findViewById(R.id.courseEndDate);
        editStatus = findViewById(R.id.courseStatus);
        editInstructorName = findViewById(R.id.courseInstructorName);
        editInstructorPhone = findViewById(R.id.courseInstructorPhone);
        editInstructorEmail = findViewById(R.id.courseInstructorEmail);
        editNotes = findViewById(R.id.courseNotes);
        if (id != -1) {
            editTitle.setText(title);
            editStartDate.setText(startDate);
            editEndDate.setText(endDate);
            editStatus.setText(status);
            editInstructorName.setText(instructorName);
            editInstructorPhone.setText(instructorPhone);
            editInstructorEmail.setText(instructorEmail);
            editNotes.setText(notes);


        }
        schedulingManagementRepository = new SchedulingManagementRepository(getApplication());

        //Logic for start and end date pickers
        //editStartDate = findViewById(R.id.courseStartDate);
        myStartDate = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                calendarStart.set(Calendar.YEAR, year);
                calendarStart.set(Calendar.MONTH, monthOfYear);
                calendarStart.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                String myFormat = "MM/dd/yy"; //In which you need put here
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                updateStartDateLabel();
            }

        };
        editStartDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(AddCourseActivity.this, myStartDate, calendarStart
                        .get(Calendar.YEAR), calendarStart.get(Calendar.MONTH),
                        calendarStart.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        myEndDate = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                calendarEnd.set(Calendar.YEAR, year);
                calendarEnd.set(Calendar.MONTH, monthOfYear);
                calendarEnd.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                String myFormat = "MM/dd/yy"; //In which you need put here
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                updateEndDateLabel();
            }

        };
        editEndDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(AddCourseActivity.this, myEndDate, calendarEnd
                        .get(Calendar.YEAR), calendarEnd.get(Calendar.MONTH),
                        calendarEnd.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        List<CourseEntity> allCourses = schedulingManagementRepository.getAllCourses();
        //search the list of our courses to pull out which coursen we want to edit.
        for (CourseEntity c : allCourses) {
            if (c.getId() == id)
                currentCourse = c;
        }

        // what is happening here?
        if (currentCourse != null) {
            title = currentCourse.getTitle();
            startDate = currentCourse.getStartDate();
            endDate = currentCourse.getEndDate();
            status = currentCourse.getStatus();
            instructorName = currentCourse.getInstructorName();
            instructorPhone = currentCourse.getInstructorPhone();
            instructorEmail = currentCourse.getInstructorEmail();
            notes = currentCourse.getNotes();
        }
        schedulingManagementRepository = new SchedulingManagementRepository(getApplication());

    }
    public void addCourseToTerm(View view) {
        CourseEntity c;

        if(id!=-1)
            c = new CourseEntity(id,termID, editTitle.getText().toString(),editStartDate.getText().toString(),
                    editEndDate.getText().toString(),editStatus.getText().toString(),editInstructorName.getText().toString(),
                    editInstructorPhone.getText().toString(),editInstructorEmail.getText().toString(),editNotes.getText().toString());
        else{
            List<CourseEntity> allCourses=schedulingManagementRepository.getAllCourses();
            id =allCourses.get(allCourses.size()-1).getId();

            c = new CourseEntity(++id,termID, editTitle.getText().toString(),editStartDate.getText().toString(),
                    editEndDate.getText().toString(),editStatus.getText().toString(),editInstructorName.getText().toString(),
                    editInstructorPhone.getText().toString(),editInstructorEmail.getText().toString(),editNotes.getText().toString());
        }
        schedulingManagementRepository.insert(c);
        Intent intent=new Intent(AddCourseActivity.this,CourseActivity.class);
        startActivity(intent);
    }
    private void updateEndDateLabel() {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        editEndDate.setText(sdf.format(calendarEnd.getTime()));
    }

    private void updateStartDateLabel() {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        editStartDate.setText(sdf.format(calendarStart.getTime()));
    }

    public void addAssessment(View view) {
        Intent intent= new Intent(AddCourseActivity.this, AddAssessmentActivity.class);
        startActivity(intent);
    }
}


