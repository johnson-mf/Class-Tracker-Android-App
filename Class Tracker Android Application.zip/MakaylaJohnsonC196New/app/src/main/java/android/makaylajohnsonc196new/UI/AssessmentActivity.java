package android.makaylajohnsonc196new.UI;

import androidx.appcompat.app.AppCompatActivity;

import android.makaylajohnsonc196new.R;
import android.os.Bundle;

public class AssessmentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assessment);
    }
}