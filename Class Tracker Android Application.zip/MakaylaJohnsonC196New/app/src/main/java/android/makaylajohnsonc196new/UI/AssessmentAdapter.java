package android.makaylajohnsonc196new.UI;

import android.content.Context;
import android.content.Intent;
import android.makaylajohnsonc196new.ClassEntities.AssessmentEntity;
import android.makaylajohnsonc196new.ClassEntities.CourseEntity;
import android.makaylajohnsonc196new.R;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

//Course -> Assessment
// Term-> Course
public class AssessmentAdapter  extends RecyclerView.Adapter<AssessmentAdapter.AssessmentViewHolder> {

    class AssessmentViewHolder extends RecyclerView.ViewHolder {
        private final TextView title;
        private final TextView endDate;
        private AssessmentViewHolder(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.assessment_text_view_title);
            endDate = itemView.findViewById(R.id.assessment_text_view_end);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    final AssessmentEntity current = mAssessment.get(position);
                    Intent intent = new Intent(context, AddAssessmentActivity.class);
                    intent.putExtra("assessmentTitle", current.getTitle());
                    intent.putExtra("assessmentID", current.getId());
                    intent.putExtra("assessmentEndDate", current.getEndDate());
                    intent.putExtra("courseID", current.getCourseID());
                    System.out.println("ON CLICK ID: " + current.getId() + "Name : " + current.getTitle() + "CourseID : " + current.getCourseID());


                    context.startActivity(intent);
                }
            });
        }

    }
    private final LayoutInflater mInflater;
    private final Context context;
    private List<AssessmentEntity> mAssessment; // Cached copy of words

    public AssessmentAdapter(Context context) {
        mInflater = LayoutInflater.from(context);
        this.context=context;
    }
    @Override
    public AssessmentAdapter.AssessmentViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.assessment_list_item, parent, false);

        return new AssessmentViewHolder(itemView);
    }
    @Override
    public void onBindViewHolder(AssessmentAdapter.AssessmentViewHolder holder, int position) {
        if (mAssessment != null) {
            AssessmentEntity current = mAssessment.get(position);
            holder.title.setText(current.getTitle());
            holder.endDate.setText(current.getEndDate());

        } else {
            // Covers the case of data not being ready yet.
            holder.title.setText("No Word");
            holder.endDate.setText("No Word");

        }

    }
    public void setWords(List<AssessmentEntity> words) {
        mAssessment = words;
        notifyDataSetChanged();
    }
    // getItemCount() is called many times, and when it is first called,
    // mWords has not been updated (means initially, it's null, and we can't return null).
    @Override
    public int getItemCount() {
        if (mAssessment != null)
            return mAssessment.size();
        else return 0;
    }
}

