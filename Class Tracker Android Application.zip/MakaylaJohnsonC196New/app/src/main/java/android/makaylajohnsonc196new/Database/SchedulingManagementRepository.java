package android.makaylajohnsonc196new.Database;

import android.app.Application;
import android.makaylajohnsonc196new.ClassEntities.AssessmentEntity;
import android.makaylajohnsonc196new.DAO.AssessmentDAO;
import android.makaylajohnsonc196new.DAO.CourseDAO;
import android.makaylajohnsonc196new.DAO.TermDAO;
import android.makaylajohnsonc196new.ClassEntities.CourseEntity;
import android.makaylajohnsonc196new.ClassEntities.TermEntity;

import java.util.List;

public class SchedulingManagementRepository {
    private TermDAO termDAO;
    private CourseDAO courseDAO;
    private AssessmentDAO assessmentDAO;
    private List<TermEntity> allTerms;
    private List<CourseEntity> allCourses;
    private List<AssessmentEntity> allAssessments;
    private int termID;

    public SchedulingManagementRepository(Application application) {

        SchedulingManagementDatabase db = SchedulingManagementDatabase.getDatabase(application);
        termDAO = db.termDAO();
        courseDAO = db.courseDAO();
        assessmentDAO = db.assessmentDAO();

        //put a delay to keep things synchronized, we need a delay. ROOM requires this
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public List<CourseEntity> getAllCourses() {
        SchedulingManagementDatabase.databaseWriteExecutor.execute(()->{
            allCourses=courseDAO.getAllCourses();
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return allCourses;
    }
    public List<TermEntity> getAllTerms() {
        SchedulingManagementDatabase.databaseWriteExecutor.execute(()->{
            allTerms=termDAO.getAllTerms();
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return allTerms;
    }
    public List<AssessmentEntity> getAllAssessments() {
        SchedulingManagementDatabase.databaseWriteExecutor.execute(()->{
            allAssessments=assessmentDAO.getAllAssessments();
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return allAssessments;
    }
    public void insert (TermEntity termEntity) {
        SchedulingManagementDatabase.databaseWriteExecutor.execute(() -> {
            termDAO.insert(termEntity);
        });try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void insert (CourseEntity courseEntity){
        SchedulingManagementDatabase.databaseWriteExecutor.execute(()->{
            courseDAO.insert(courseEntity);
        });try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void insert (AssessmentEntity assessmentEntity) {
        SchedulingManagementDatabase.databaseWriteExecutor.execute(() -> {
            assessmentDAO.insert(assessmentEntity);
        });try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void delete (TermEntity termEntity){
        SchedulingManagementDatabase.databaseWriteExecutor.execute(()->{
            termDAO.delete(termEntity);
        });try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void delete (CourseEntity courseEntity){
        SchedulingManagementDatabase.databaseWriteExecutor.execute(()->{
            courseDAO.delete(courseEntity);
        });try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void delete (AssessmentEntity assessmentEntity){
        SchedulingManagementDatabase.databaseWriteExecutor.execute(()->{
            assessmentDAO.delete(assessmentEntity);
        });try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}
