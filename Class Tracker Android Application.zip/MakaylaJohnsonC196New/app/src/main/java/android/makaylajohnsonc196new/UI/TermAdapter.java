package android.makaylajohnsonc196new.UI;

import android.content.Context;
import android.content.Intent;
import android.makaylajohnsonc196new.ClassEntities.TermEntity;
import android.makaylajohnsonc196new.R;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TermAdapter extends RecyclerView.Adapter<TermAdapter.TermViewHolder> {


    class TermViewHolder extends RecyclerView.ViewHolder{
        private final TextView termTitleText;
        private final TextView termStartText;
        private final TextView termEndText;

        private TermViewHolder(View itemView){
            super(itemView);
            termTitleText= itemView.findViewById(R.id.text_view_title);
            termStartText= itemView.findViewById(R.id.text_view_start);
            termEndText= itemView.findViewById(R.id.text_view_end);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    final TermEntity current = mTerms.get(position);
                    Intent intent = new Intent(context, CourseActivity.class);
                    intent.putExtra("termTitle", current.getTitle());
                    intent.putExtra("termID", current.getId());
                    intent.putExtra("termStartDate", current.getStartDate());
                    intent.putExtra("termEndDate", current.getEndDate());
                    intent.putExtra("position", position);

                    context.startActivity(intent);


                }
            });
        }
    }
    private final LayoutInflater mInflater;
    private final Context context;
    private List<TermEntity> mTerms; // list that will be shown

    public TermAdapter(Context context){
        mInflater=LayoutInflater.from(context);
        this.context = context;

    }

    //inflating a list item several times then binding it together to create a list
    @Override
    public TermViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View itemView = mInflater.inflate(R.layout.term_list_item, parent, false);
        return new TermViewHolder(itemView);
    }
    @Override
    public void onBindViewHolder(TermViewHolder holder, int position) {

        if (mTerms != null) {
            final TermEntity current = mTerms.get(position);
            holder.termTitleText.setText(current.getTitle());
            holder.termStartText.setText(current.getStartDate());
            holder.termEndText.setText(current.getEndDate());

        } else {
            // just in case the data is not available yet-
            holder.termTitleText.setText("No Name");
            holder.termStartText.setText("No Start!");
            holder.termEndText.setText("No End");

        }
    }

    //used with the method blow
    @Override
    public int getItemCount() {
        if (mTerms != null)
            return mTerms.size();
        else return 0;
    }

    //we want "words" to be set to the size of the list, so that it knows when data changes
    public void setWords(List<TermEntity> words) {
        mTerms = words;
        notifyDataSetChanged();
    }
}
