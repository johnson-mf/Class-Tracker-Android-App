package android.makaylajohnsonc196new.ClassEntities;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName= "Assessment_Table")
public class AssessmentEntity {

    @PrimaryKey
    private int id;

    @ColumnInfo(name = "Title")
    private String title;

    @ColumnInfo(name = "End_Date")
    private String endDate;

    @ColumnInfo(name = "Course_ID")
    private int courseID;

    @Override
    public String toString() {
        return "AssessmentEntity{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", endDate=" + endDate +
                ", courseID=" + courseID +
                '}';
    }
    public AssessmentEntity(int id,String title, String endDate, int courseID) {
        this.id=id;
        this.title = title;
        this.endDate = endDate;
        this.courseID=courseID;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public int getCourseID() {
        return courseID;
    }

    public void setCourseID(int courseID) {
        this.courseID = courseID;
    }
}
