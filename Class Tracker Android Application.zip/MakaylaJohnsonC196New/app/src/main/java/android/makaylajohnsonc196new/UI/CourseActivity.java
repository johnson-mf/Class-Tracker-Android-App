package android.makaylajohnsonc196new.UI;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.makaylajohnsonc196new.ClassEntities.CourseEntity;
import android.makaylajohnsonc196new.ClassEntities.TermEntity;
import android.makaylajohnsonc196new.Database.SchedulingManagementRepository;
import android.makaylajohnsonc196new.R;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class CourseActivity extends AppCompatActivity {
    public static int numberOfCourses;
    private SchedulingManagementRepository schedulingManagementRepository;
    int Id;

    String title;
    String startDate;
    String endDate;

    EditText editTitle;
    EditText editStartDate;
    EditText editEndDate;
    List<CourseEntity> filteredCourses = new ArrayList<>();
    TermEntity currentTerm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course);
        //what is happening here?
        Id=getIntent().getIntExtra("termID",-1);
        if (Id==-1)
            Id=CourseDetail.id2;
        schedulingManagementRepository= new SchedulingManagementRepository(getApplication());
        List<TermEntity> allTerms = schedulingManagementRepository.getAllTerms();
        //search the list of our terms to pull out which term we want to edit.
        for(TermEntity t:allTerms){
            if(t.getId()==Id)
                currentTerm=t;
        }
        editTitle=findViewById(R.id.termTitle);
        editStartDate=findViewById(R.id.termStartDate);
        editEndDate =findViewById(R.id.termEndDate);

        // what is happening here?
        if(currentTerm!=null){
            title=currentTerm.getTitle();
            startDate=currentTerm.getStartDate();
            endDate=currentTerm.getEndDate();
        }
        //if we are editing an existing term. we will take the term we have and set the fields to it.
        if(Id!=-1){
            editTitle.setText(title);
            editStartDate.setText(startDate);
            editEndDate.setText(endDate);
        }
        schedulingManagementRepository = new SchedulingManagementRepository(getApplication());

        RecyclerView recyclerView = findViewById(R.id.associated_courses);
        final CourseAdapter adapter = new CourseAdapter(this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //Why doesnt this work?
        filteredCourses.clear();

        //we will grab a list of all courses, and add the courses that have a matching term id with our currentTerm.
        for(CourseEntity c: schedulingManagementRepository.getAllCourses()){
            if(c.getTermID()==Id)
                filteredCourses.add(c);
        }
        numberOfCourses = filteredCourses.size();
        adapter.setWords(filteredCourses);
        }


    public void addCourse(View view) {
        Intent intent=new Intent(CourseActivity.this,AddCourseActivity.class);
        intent.putExtra("termID",Id);
        startActivity(intent);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.delete_term, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //logic for deleting a course
        int id = item.getItemId();


        if (id == R.id.deleteTerm) {
            if(numberOfCourses==0) {
                schedulingManagementRepository.delete(currentTerm);
                Intent intent=new Intent(CourseActivity.this,TermActivity.class);
                startActivity(intent);
            }
            else{
                Toast.makeText(getApplicationContext(),"Can't delete a term with courses tied to it!",Toast.LENGTH_LONG).show();// make another toast
            }
        }


        return super.onOptionsItemSelected(item);
    }

    public void addTermFromScreen(View view) {
        TermEntity t;
       // how does this deal with the old term that may still exist?
        if(Id!=-1)
            t = new TermEntity(Id,editTitle.getText().toString(),editStartDate.getText().toString(),editEndDate.getText().toString());
        else{
            List<TermEntity> allTerms=schedulingManagementRepository.getAllTerms();
            Id=allTerms.get(allTerms.size()-1).getId();
            t = new TermEntity(++Id,editTitle.getText().toString(),editStartDate.getText().toString(),editEndDate.getText().toString());
        }
        schedulingManagementRepository.insert(t);

        Intent intent=new Intent(CourseActivity.this,TermActivity.class);
        startActivity(intent);

    }
}
/* for (CourseEntity c: filteredCourses){
            System.out.println("Ac Filtered Courses Name:" +c.getTitle());

        } for(CourseEntity c: schedulingManagementRepository.getAllCourses()){
            System.out.println("All Courses Name:" +c.getTitle());

        }
        for (CourseEntity c: filteredCourses){
            System.out.println("Filtered Courses Name:" +c.getTitle());

        }*/
