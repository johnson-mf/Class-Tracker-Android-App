package android.makaylajohnsonc196new.ClassEntities;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName= "Course_Table")
public class CourseEntity {

    @PrimaryKey
    private int id;

    @ColumnInfo(name = "Term_ID")
    private int termID;

    @ColumnInfo(name = "Title")
    private String title;

    @ColumnInfo(name = "Start_Date")
    private String startDate;

    @ColumnInfo(name = "End_Date")
    private String endDate;

    @ColumnInfo(name = "Status")
    private String status;

    @ColumnInfo(name = "Instructor_Name")
    private String instructorName;

    @ColumnInfo(name = "Instructor_Phone")
    private String instructorPhone;

    @ColumnInfo(name = "Instructor_Email")
    private String instructorEmail;

    @ColumnInfo(name = "Notes")
    private String notes;

    @Override
    public String toString() {
        return "CourseEntity{" +
                "courseID=" + id +
                ", courseTitle='" + title + '\'' +
                ", termID=" + termID +
                ", courseStartDate=" + startDate +
                ", courseEndDate=" + endDate +
                ", courseStatus =" + status +
                ", instructorName =" + instructorName +
                ", instructorPhone =" + instructorPhone +
                ", instructorEmail =" + instructorEmail +
                ", notes =" + notes +
                '}';
    }
    public CourseEntity(int id, int termID, String title, String startDate, String endDate, String status, String instructorName, String instructorPhone, String instructorEmail, String notes) {
        this.id = id;
        this.termID = termID;
        this.title = title;
        this.startDate = startDate;
        this.endDate = endDate;
        this.status = status;
        this.instructorName = instructorName;
        this.instructorPhone = instructorPhone;
        this.instructorEmail = instructorEmail;
        this.notes=notes;
    }

    public int getTermID() {
        return termID;
    }

    public void setTermID(int termID) {
        this.termID = termID;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getStartDate() {
        return startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public String getStatus() {
        return status;
    }

    public String getInstructorName() {
        return instructorName;
    }

    public String getInstructorPhone() {
        return instructorPhone;
    }

    public String getInstructorEmail() {
        return instructorEmail;
    }

    public String getNotes() {
        return notes;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setInstructorName(String instructorName) {
        this.instructorName = instructorName;
    }

    public void setInstructorPhone(String instructorPhone) {
        this.instructorPhone = instructorPhone;
    }

    public void setInstructorEmail(String instructorEmail) {
        this.instructorEmail = instructorEmail;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
}

