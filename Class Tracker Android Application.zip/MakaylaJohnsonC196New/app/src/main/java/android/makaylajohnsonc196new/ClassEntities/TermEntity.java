package android.makaylajohnsonc196new.ClassEntities;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName="Term_Table")
public class TermEntity {

    @PrimaryKey
    private int id;

    @ColumnInfo(name = "Title")
    private String title;

    @ColumnInfo(name = "Start_Date")
    private String startDate;

    @ColumnInfo(name = "End_Date")
    private String endDate;

    @Override
    public String toString() {
        return "TermEntity{" +
                "termID=" + id +
                ", termTitle='" + title + '\'' +
                ", termStartDate=" + startDate +
                ", termEndDate=" + endDate +

                '}';
    }
    public TermEntity(int id, String title, String startDate, String endDate) {
        this.id=id;
        this.title = title;
        this.startDate = startDate;
        this.endDate = endDate;

    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getStartDate() {
        return startDate;
    }

    public String getEndDate() {
        return endDate;
    }



    public void setId(int id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

}
